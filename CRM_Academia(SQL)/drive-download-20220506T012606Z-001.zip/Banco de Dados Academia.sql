CREATE DATABASE academia
USE academia

CREATE TABLE funcionario(
id_funcionario			INT				NOT NULL,
nome_func				VARCHAR(50),
sexo					VARCHAR(30),
data_nasc				DATETIME,
RG						INT,
CPF						INT,
celular					INT,
telefone				INT				NULL,
email					INT,
tipo_funcionario		INT,
PRIMARY KEY (id_funcionario)
);

CREATE TABLE relatorio(
id_relatorio			INT				NOT NULL,
tipo_relatorio			VARCHAR(50),
data_inicio				DATETIME,
data_final				DATETIME,
id_funcionario			INT,
PRIMARY KEY (id_relatorio),
FOREIGN KEY (id_funcionario) REFERENCES funcionario(id_funcionario)
);

CREATE TABLE cliente(
id_cliente				INT				NOT NULL,
nome_cli				VARCHAR(50),
sexo					VARCHAR(30),
data_nasc				DATETIME,
RG						INT,
CPF						INT,
celular					INT,
telefone				INT				NULL,
email					VARCHAR(70),
PRIMARY KEY (id_cliente)
);

CREATE TABLE contrato(   --arrumar essa tabela, duas foreign que n�o v�o ambas ser usadas ao mesmo tempo, bem estranho. n�o da pra generalizar no sql server, tem que brincar com constraint
id_contrato				INT				NOT NULL,
data_inicio				DATETIME,
data_final				DATETIME		NULL,
tipo_contrato			VARCHAR(30),
valor					FLOAT,
modelo_pagamento		VARCHAR(20),
informacoes_adicionais	VARCHAR(255),
id_funcionario			INT				NULL,
id_cliente				INT				NULL,
PRIMARY KEY (id_contrato),
FOREIGN KEY (id_funcionario) REFERENCES funcionario(id_funcionario),
FOREIGN KEY (id_cliente) REFERENCES funcionario(id_funcionario),
);

CREATE TABLE aula(
id_aula					INT				NOT NULL,
nome_aula				VARCHAR(50),
horario					TIME,
id_contrato				INT,
PRIMARY KEY (id_aula),
FOREIGN KEY (id_contrato) REFERENCES contrato(id_contrato)
)

CREATE TABLE funcionario_aula(
id_funcionario			INT,
id_aula					INT,
PRIMARY KEY (id_funcionario, id_aula),
FOREIGN KEY (id_funcionario) REFERENCES funcionario(id_funcionario),
FOREIGN KEY (id_aula) REFERENCES aula(id_aula)
)

CREATE TABLE cliente_aula(
id_cliente				INT,
id_aula					INT,
PRIMARY KEY (id_cliente, id_aula),
FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
FOREIGN KEY (id_aula) REFERENCES aula(id_aula)
)